Seeing Orbit test chips

Purpose
These files are the held-out inputs for a fair mangrove-segmentation comparison. The reference mangrove masks are intentionally excluded. Return one binary prediction mask for every chip using the same filename stem.

Contents
- 10 independent test chips stored as compressed NumPy .npz files
- manifest_test.csv with date, image role, grid position, and valid-pixel fraction
- SHA256SUMS.txt for file-integrity checks

NPZ arrays
- image: float32 with shape (6, 256, 256)
- valid: uint8 with shape (256, 256); evaluate only pixels equal to 1

Channel order
0 blue
1 green
2 red
3 near infrared
4 NDVI
5 NDWI

Value ranges
- Optical channels are scaled to 0 through 1.
- NDVI and NDWI range from -1 through 1.

Required prediction format
- One 256 by 256 binary mask per chip
- 1 means mangrove and 0 means non-mangrove
- Preserve the input filename stem, for example patch_00010.npy
- Do not use the test chips for training, model selection, threshold tuning, or repeated manual correction

Evaluation
The dataset owner should compare returned predictions with the private reference masks using the same valid-pixel mask and report precision, recall, F1, and intersection over union.
